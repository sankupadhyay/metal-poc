'use strict';

import templates from './NewsBox.soy.js';
import Component from 'metal-component';
import Soy from 'metal-soy';

import './NewsBox.scss';

class NewsBox extends Component {
}
Soy.register(NewsBox, templates);

export { NewsBox };
export default NewsBox;
