/* jshint ignore:start */
import Component from 'metal-component';
import Soy from 'metal-soy';

var templates;
goog.loadModule(function(exports) {
var soy = goog.require('soy');
var soydata = goog.require('soydata');
// This file was automatically generated from NewsBox.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace NewsBox.
 * @public
 */

goog.module('NewsBox.incrementaldom');

var incrementalDom = goog.require('incrementaldom');
var soyIdom = goog.require('soy.idom');


/**
 * @param {Object<string, *>=} opt_data
 * @param {Object<string, *>=} opt_ijData
 * @param {Object<string, *>=} opt_ijData_deprecated
 * @return {void}
 * @suppress {checkTypes}
 */
function $render(opt_data, opt_ijData, opt_ijData_deprecated) {
  opt_ijData = opt_ijData_deprecated || opt_ijData;
  incrementalDom.elementOpenStart('div');
      incrementalDom.attr('class', 'col-md-3');
  incrementalDom.elementOpenEnd();
    incrementalDom.elementOpenStart('div');
        incrementalDom.attr('class', 'row');
        incrementalDom.attr('align', 'center');
    incrementalDom.elementOpenEnd();
      incrementalDom.elementOpenStart('img');
          incrementalDom.attr('src', 'img/news4.jpg');
          incrementalDom.attr('class', 'news-box-img');
      incrementalDom.elementOpenEnd();
      incrementalDom.elementClose('img');
    incrementalDom.elementClose('div');
    incrementalDom.elementOpenStart('div');
        incrementalDom.attr('class', 'row');
    incrementalDom.elementOpenEnd();
      incrementalDom.elementOpenStart('div');
          incrementalDom.attr('class', 'col-md-10');
      incrementalDom.elementOpenEnd();
        incrementalDom.elementOpenStart('span');
            incrementalDom.attr('class', 'news-box-header');
        incrementalDom.elementOpenEnd();
          incrementalDom.text('Within the construction industry as their overdraft');
        incrementalDom.elementClose('span');
      incrementalDom.elementClose('div');
    incrementalDom.elementClose('div');
    incrementalDom.elementOpenStart('div');
        incrementalDom.attr('class', 'row');
    incrementalDom.elementOpenEnd();
      incrementalDom.elementOpenStart('div');
          incrementalDom.attr('class', 'col-md-10');
      incrementalDom.elementOpenEnd();
        incrementalDom.elementOpenStart('img');
            incrementalDom.attr('src', '');
            incrementalDom.attr('class', 'icon');
        incrementalDom.elementOpenEnd();
        incrementalDom.elementClose('img');
        incrementalDom.elementOpenStart('span');
            incrementalDom.attr('class', 'text');
        incrementalDom.elementOpenEnd();
          incrementalDom.text('January 22, 2016');
        incrementalDom.elementClose('span');
      incrementalDom.elementClose('div');
    incrementalDom.elementClose('div');
  incrementalDom.elementClose('div');
}
exports.render = $render;
if (goog.DEBUG) {
  $render.soyTemplateName = 'NewsBox.render';
}

exports.render.params = [];
exports.render.types = {};
templates = exports;
return exports;

});

class NewsBox extends Component {}
Soy.register(NewsBox, templates);
export { NewsBox, templates };
export default templates;
/* jshint ignore:end */
