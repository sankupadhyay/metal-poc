/* jshint ignore:start */
import Component from 'metal-component';
import Soy from 'metal-soy';

var templates;
goog.loadModule(function(exports) {
var soy = goog.require('soy');
var soydata = goog.require('soydata');
// This file was automatically generated from Theme.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Theme.
 * @public
 */

goog.module('Theme.incrementaldom');

var soyIdom = goog.require('soy.idom');

var $templateAlias1 = Soy.getTemplate('NewsBox.incrementaldom', 'render');


/**
 * @param {Object<string, *>=} opt_data
 * @param {Object<string, *>=} opt_ijData
 * @param {Object<string, *>=} opt_ijData_deprecated
 * @return {void}
 * @suppress {checkTypes}
 */
function $render(opt_data, opt_ijData, opt_ijData_deprecated) {
  opt_ijData = opt_ijData_deprecated || opt_ijData;
  $templateAlias1(null, null, opt_ijData);
}
exports.render = $render;
if (goog.DEBUG) {
  $render.soyTemplateName = 'Theme.render';
}

exports.render.params = [];
exports.render.types = {};
templates = exports;
return exports;

});

class Theme extends Component {}
Soy.register(Theme, templates);
export { Theme, templates };
export default templates;
/* jshint ignore:end */
